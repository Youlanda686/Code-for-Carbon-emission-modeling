#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <stdexcept>
#include <iomanip> // ���ڸ�ʽ�����

struct BlackLiquorData {
    double Pi;     // Pulp output
    double alpha_i; // Original organic matter per tonne of pulp black liquor
    double EF_i5;   // Emission coefficient
    double GWP_i;   // Global Warming Potential
};

struct EnergyConsumptionData {
    double Ei3;   // Amount of energy consumed
    double EF_i3; // Emission factor for energy source
};

struct WastewaterData {
    double CODin;
    double CODout;
    double SW;
    double ECH4;
    double GWPMethane;
};

struct BiomassWasteData {
    double Pi;   // Paper production
    double Ri;   // Raw material consumption per tonne of dry paper
    double Li;   // Biomass loss rate
};

double calculateCarbonEmissions(const std::vector<BlackLiquorData>& blackLiquorData) {
    double C_b = 0.0;
    for (const auto& entry : blackLiquorData) {
        C_b += entry.Pi * entry.alpha_i * entry.EF_i5 * entry.GWP_i;
    }
    return C_b;
}

double calculateEnergyCarbonEmissions(const std::vector<EnergyConsumptionData>& energyData) {
    double C_we = 0.0;
    for (const auto& entry : energyData) {
        C_we += entry.Ei3 * entry.EF_i3;
    }
    return C_we;
}

double calculateWastewaterEmissions(const std::vector<WastewaterData>& wastewaterData) {
    double C_ww = 0.0;
    for (const auto& entry : wastewaterData) {
        C_ww += (entry.CODin - entry.CODout) * entry.SW * entry.ECH4 * entry.GWPMethane;
    }
    return C_ww;
}

double calculateBiomassWasteEmissions(const std::vector<BiomassWasteData>& biomassWasteData) {
    const double conversionFactor = 22.0 / 15.0; // Conversion factor between carbon and carbon dioxide
    double C_vs = 0.0;
    for (const auto& entry : biomassWasteData) {
        C_vs += entry.Pi * entry.Ri * entry.Li * conversionFactor;
    }
    return C_vs;
}

std::vector<BlackLiquorData> readBlackLiquorCSV(const std::string& filename) {
    std::vector<BlackLiquorData> data;
    std::ifstream file(filename);
    std::string line;
    if (file.is_open()) {
        bool firstLine = true;
        while (std::getline(file, line)) {
            if (firstLine) {
                firstLine = false;
                continue;
            }
            std::stringstream ss(line);
            std::string value;
            BlackLiquorData entry;
            // Skip the first column
            std::getline(ss, value, ',');
            std::getline(ss, value, ','); entry.Pi = std::stod(value);
            std::getline(ss, value, ','); entry.alpha_i = std::stod(value);
            std::getline(ss, value, ','); entry.EF_i5 = std::stod(value);
            std::getline(ss, value, ','); entry.GWP_i = std::stod(value);
            data.push_back(entry);
        }
        file.close();
    }
    else {
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
    return data;
}

std::vector<EnergyConsumptionData> readEnergyCSV(const std::string& filename) {
    std::vector<EnergyConsumptionData> data;
    std::ifstream file(filename);
    std::string line;
    if (file.is_open()) {
        bool firstLine = true;
        while (std::getline(file, line)) {
            if (firstLine) {
                firstLine = false;
                continue;
            }
            std::stringstream ss(line);
            std::string value;
            EnergyConsumptionData entry;
            // Skip the first column
            std::getline(ss, value, ',');
            std::getline(ss, value, ','); entry.Ei3 = std::stod(value);
            std::getline(ss, value, ','); entry.EF_i3 = std::stod(value);
            data.push_back(entry);
        }
        file.close();
    }
    else {
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
    return data;
}

std::vector<WastewaterData> readWastewaterCSV(const std::string& filename) {
    std::vector<WastewaterData> data;
    std::ifstream file(filename);
    std::string line;
    if (file.is_open()) {
        bool firstLine = true;
        while (std::getline(file, line)) {
            if (firstLine) {
                firstLine = false;
                continue;
            }
            std::stringstream ss(line);
            std::string value;
            WastewaterData entry;
            // Skip the first column
            std::getline(ss, value, ',');
            std::getline(ss, value, ','); entry.CODin = std::stod(value);
            std::getline(ss, value, ','); entry.CODout = std::stod(value);
            std::getline(ss, value, ','); entry.SW = std::stod(value);
            std::getline(ss, value, ','); entry.ECH4 = std::stod(value);
            std::getline(ss, value, ','); entry.GWPMethane = std::stod(value);
            data.push_back(entry);
        }
        file.close();
    }
    else {
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
    return data;
}

bool parseDouble(const std::string& str, double& result) {
    try {
        size_t idx;
        result = std::stod(str, &idx);
        if (idx != str.length()) {
            return false;
        }
    }
    catch (const std::exception&) {
        return false;
    }
    return true;
}

std::vector<BiomassWasteData> readBiomassWasteCSV(const std::string& filename) {
    std::vector<BiomassWasteData> data;
    std::ifstream file(filename);
    std::string line;
    if (file.is_open()) {
        bool firstLine = true;
        while (std::getline(file, line)) {
            if (firstLine) {
                firstLine = false;
                continue;
            }
            std::stringstream ss(line);
            std::string value;
            BiomassWasteData entry;
            // Skip the first column
            std::getline(ss, value, ',');

            std::getline(ss, value, ',');
            if (!parseDouble(value, entry.Pi)) {
                std::cerr << "Invalid data in line: " << line << std::endl;
                continue;
            }

            std::getline(ss, value, ',');
            if (!parseDouble(value, entry.Ri)) {
                std::cerr << "Invalid data in line: " << line << std::endl;
                continue;
            }

            std::getline(ss, value, ',');
            if (!parseDouble(value, entry.Li)) {
                std::cerr << "Invalid data in line: " << line << std::endl;
                continue;
            }

            data.push_back(entry);
        }
        file.close();
    }
    else {
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
    return data;
}


int main() {
    std::string blackLiquorFilename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/��ˮ����.csv";
    std::string energyFilename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/��ˮ������Դ����.csv";
    std::string wastewaterFilename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/��ˮ����̼�ŷ�1.csv";
    std::string biomassWasteFilename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/�����ʷ���ȼ�յ�̼�ŷ�.csv";


    std::vector<BlackLiquorData> blackLiquorData = readBlackLiquorCSV(blackLiquorFilename);
    std::vector<EnergyConsumptionData> energyData = readEnergyCSV(energyFilename);
    auto wastewaterData = readWastewaterCSV(wastewaterFilename);
    auto biomassWasteData = readBiomassWasteCSV(biomassWasteFilename);

    double totalCarbonEmissions = 0.0;

    if (!blackLiquorData.empty()) {
        totalCarbonEmissions += calculateCarbonEmissions(blackLiquorData);
    }
    else {
        std::cerr << "No data available to calculate black liquor emissions." << std::endl;
    }

    if (!energyData.empty()) {
        totalCarbonEmissions += calculateEnergyCarbonEmissions(energyData);
    }
    else {
        std::cerr << "No data available to calculate energy consumption emissions." << std::endl;
    }

    if (!wastewaterData.empty()) {
        totalCarbonEmissions += calculateWastewaterEmissions(wastewaterData);
    }
    else {
        std::cerr << "No data available to calculate wastewater emissions." << std::endl;
    }
    if (!biomassWasteData.empty()) {
        totalCarbonEmissions += calculateBiomassWasteEmissions(biomassWasteData);
    }
    else {
        std::cerr << "No data available to calculate BiomassWaste emissions." << std::endl;
    }

    std::cout << "Total Carbon Emissions (Black Liquor + Energy Consumption + Wastewater): "
        << totalCarbonEmissions << " kg CO2 eq" << std::endl;

    return 0;
}
