#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
using namespace std;
struct Resource {
    std::string name;
    double quantity;
    double emission_factor;
};

struct Rawmaterial {
    double V;   // ľ���������λ������
    double K1;  // �ֹ����ܺģ���λGJ/m^3
    double EF;  // ���������ŷ�ϵ��
    double GWP; // ȫ���ůǱ��
};

struct Transport {
    double M;   // ľ����������λ��
    double L;   // ������룬��λǧ��
    double K2;  // �ֹ����ܺģ���λGJ/tonne.km
    double EF;  // ���������ŷ�ϵ��
    double GWP; // ȫ���ůǱ��
};




// ���㻯ѧƷ���ŷ�
double calculate_chemical_emissions(const std::vector<Resource>& chemicals) {
    double total_emissions = 0.0;
    for (const auto& chem : chemicals) {
        total_emissions += chem.quantity * chem.emission_factor;
    }
    return total_emissions;
}



//�����ֽ�ռ���̼�ŷ�
double calculate_papercollection_emissions(const std::vector<Resource>& papercollection) {
    double total_emissions = 0.0;
    for (const auto& papercoll : papercollection){
        total_emissions += papercoll.quantity * papercoll.emission_factor;
        }
    return total_emissions;
}

// ����������̵��ŷ�
double calculate_manufacturing_emissions(const std::vector<Resource>& manufacturing) {
    double total_emissions = 0.0;
    for (const auto& man : manufacturing) {
        total_emissions += man.quantity * man.emission_factor;
    }
    return total_emissions;
}


double calculate_transport_emissions(const Transport& transport) {
    return transport.M * transport.L * transport.K2 * transport.EF * transport.GWP;
}

double calculate_rawmaetrial_emissions(const Rawmaterial& rawmaterial) {
    return rawmaterial.V * rawmaterial.K1 * rawmaterial.EF * rawmaterial.GWP;
}


Transport read_transport_data(const std::string& filename) {
    Transport transport{ 0, 0, 0, 0, 0 }; // ��ʼ�����г�ԱΪ0
    std::ifstream file(filename);
    std::string line;
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return transport;
    }

    std::getline(file, line); // Skip header

    if (std::getline(file, line)) {
        std::istringstream iss(line);
        iss >> transport.M >> transport.L >> transport.K2 >> transport.EF >> transport.GWP;
    }
    file.close();
    return transport;
}

Rawmaterial read_rawmaetrial_data(const std::string& filename) {
    Rawmaterial rawmaterial{ 0, 0, 0, 0 }; // ��ʼ�����г�ԱΪ0
    std::ifstream file(filename);
    std::string line;
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return rawmaterial;
    }

    std::getline(file, line); // Skip header

    if (std::getline(file, line)) {
        std::istringstream iss(line);
        iss >> rawmaterial.V >> rawmaterial.K1 >> rawmaterial.EF >> rawmaterial.GWP;
    }
    file.close();
    return rawmaterial;
}


// ��ȡ��ѧƷ����
std::vector<Resource> read_chemical_data(const std::string& filename) {
    std::vector<Resource> chemicals;
    std::ifstream file(filename);
    std::string line, name;
    double quantity, emission_factor;

    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return chemicals;
    }

    std::getline(file, line); // Skip header

    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::getline(iss, name, ',');
        iss >> quantity;
        iss.ignore(); // Ignore the comma
        iss >> emission_factor;
        chemicals.push_back({ name, quantity, emission_factor });
    }
    file.close();
    return chemicals;
}

// ��ȡ�����������
std::vector<Resource> read_manufacturing_data(const std::string& filename) {
    std::vector<Resource> manufacturing;
    std::ifstream file(filename);
    std::string line, name;
    double quantity, emission_factor;

    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return manufacturing;
    }

    std::getline(file, line); // Skip header

    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::getline(iss, name, ',');
        iss >> quantity;
        iss.ignore(); // Ignore the comma
        iss >> emission_factor;
        manufacturing.push_back({ name, quantity, emission_factor });
    }
    file.close();
    return manufacturing;
}

//��ȡ��ֽ�ռ�����
std::vector<Resource> read_papercollection_data(const std::string& filename) {
    std::vector<Resource> papercoll;
    std::ifstream file(filename);
    std::string line, name;
    double quantity, emission_factor;

    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return papercoll;
    }

    std::getline(file, line); // Skip header

    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::getline(iss, name, ',');
        iss >> quantity;
        iss.ignore(); // Ignore the comma
        iss >> emission_factor;
        papercoll.push_back({ name, quantity, emission_factor });
    }
    file.close();
    return papercoll;
}

int main() {
    std::string chemicals_filename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/��ѧƷ����.csv";
    std::string manufacturing_filename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/�������.csv";
    std::string papercoll_filename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/��ֽ�ռ�.csv";
    std::string transport_filename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/ԭ�������ŷ�.csv";
    std::string rawmaterial_filename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ������/ԭ�ϻ�ȡ.csv";
    auto chemicals = read_chemical_data(chemicals_filename);
    auto manufacturing = read_manufacturing_data(manufacturing_filename);
    auto papercoll = read_manufacturing_data(papercoll_filename);
    auto transport = read_transport_data(transport_filename);
    auto rawmaterial = read_rawmaetrial_data(rawmaterial_filename);
    double total_chemicals_emissions = calculate_chemical_emissions(chemicals);
    double total_manufacturing_emissions = calculate_manufacturing_emissions(manufacturing);
    double total_papercollection_emissions = calculate_papercollection_emissions(papercoll);
    double total_transport_emissions = calculate_transport_emissions(transport);
    double total_rawmaterial_emissions = calculate_rawmaetrial_emissions(rawmaterial);
    double total_emissions = total_chemicals_emissions + total_manufacturing_emissions + total_papercollection_emissions + total_transport_emissions + total_rawmaterial_emissions;
    std::cout << "Total CO2 emissions (in kg CO2 eq): " << total_emissions << std::endl;
    return 0;
}

