#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>


struct Recycle
{
    double Eir = 0;
    double EFi5 = 0;
    double Mjr = 0;
    double EFjr = 0;
};

struct Landfill
{
    double W = 0;
    double Xdoc = 0;
    double Xdocf = 0;
    double Ymcf = 0;
    double F = 0;
};

struct Burn
{
    double W = 0;
    double Acf = 0;
    double Bfcf = 0;
    double Eof = 0;
};

double calculate_recycle(const std::string& filename)
{
    std::ifstream file(filename); 
    if (!file.is_open())
    {
        std::cerr << "recycle" << std::endl;
        return 0;
    }

    std::string line;

    std::getline(file, line);

    double sum = 0.0;


    while (std::getline(file, line))
    {
        std::stringstream ss(line);
        std::string item;
        Recycle data;


        std::getline(ss, item, ',');
        data.Eir = std::stod(item);

        std::getline(ss, item, ',');
        data.EFi5 = std::stod(item);

        std::getline(ss, item, ',');
        data.Mjr = std::stod(item);

        std::getline(ss, item, ',');
        data.EFjr = std::stod(item);

        sum += (data.Eir * data.EFi5) - (data.Mjr * data.EFjr);
    }

    file.close(); 
    return sum;   
}

double calculate_landfill(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "landfill" << std::endl;
        return 0;
    }

    std::string line;
    std::getline(file, line);

    double totalCL = 0.0;

    while (std::getline(file, line))
    {
        std::stringstream ss(line);
        std::string item;
        Landfill data;


        std::getline(ss, item, ',');
        data.W = std::stod(item);

        std::getline(ss, item, ',');
        data.Xdoc = std::stod(item);

        std::getline(ss, item, ',');
        data.Xdocf = std::stod(item);

        std::getline(ss, item, ',');
        data.Ymcf = std::stod(item);

        std::getline(ss, item, ',');
        data.F = std::stod(item);


        double CCH4 = data.W * data.Xdoc * data.Xdocf * data.Ymcf * data.F * (16.0 / 12.0);


        double CCO2 = data.W * data.Xdoc * data.Xdocf * (1.0 - data.Ymcf * data.F) * (44.0 / 12.0);


        double CL = CCO2 + CCH4 * 28.0;


        totalCL += CL;
    }

    file.close();
    return totalCL;
}

double calculate_burn(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "burn" << std::endl;
        return 0;
    }

    std::string line;

    std::getline(file, line);

    double totalCI = 0.0;

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string item;
        Burn data;

        std::getline(ss, item, ',');
        data.W = std::stod(item);

        std::getline(ss, item, ',');
        data.Acf = std::stod(item);

        std::getline(ss, item, ',');
        data.Bfcf = std::stod(item);

        std::getline(ss, item, ',');
        data.Eof = std::stod(item);


        double CI = data.W * data.Acf * data.Bfcf * data.Eof * (44.0 / 12.0);

        totalCI += CI;
    }

    file.close();
    return totalCI;
}

int main()
{
    std::string recycle_file = "recycle.csv";
    std::string landfill_file = "landfill.csv";
    std::string burn_file = "burn.csv";

    double recycle = calculate_recycle(recycle_file);
    double landfill = calculate_landfill(landfill_file);
    double burn = calculate_burn(burn_file);

    std::cout << "recycle+landefill+burn: " << recycle + landfill + burn << std::endl;
}