#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <stdexcept>

struct BlackLiquorData {
    double Pi;     // Pulp output
    double alpha_i; // Original organic matter per tonne of pulp black liquor
    double EF_i5;   // Emission coefficient
    double GWP_i;   // Global Warming Potential
};

struct EnergyConsumptionData {
    double Ei3;   // Amount of energy consumed
    double EF_i3; // Emission factor for energy source
};

double calculateCarbonEmissions(const std::vector<BlackLiquorData>& blackLiquorData) {
    double C_b = 0.0;
    for (const auto& entry : blackLiquorData) {
        C_b += entry.Pi * entry.alpha_i * entry.EF_i5 * entry.GWP_i;
    }
    return C_b;
}

double calculateEnergyCarbonEmissions(const std::vector<EnergyConsumptionData>& energyData) {
    double C_we = 0.0;
    for (const auto& entry : energyData) {
        C_we += entry.Ei3 * entry.EF_i3;
    }
    return C_we;
}

std::vector<BlackLiquorData> readBlackLiquorCSV(const std::string& filename) {
    std::vector<BlackLiquorData> data;
    std::ifstream file(filename);
    std::string line;
    if (file.is_open()) {
        bool firstLine = true;
        while (std::getline(file, line)) {
            if (firstLine) {
                firstLine = false;
                continue;
            }

            std::stringstream ss(line);
            std::string value;
            BlackLiquorData entry;

            // Skip the first column
            std::getline(ss, value, ',');

            try {
                std::getline(ss, value, ',');
                entry.Pi = std::stod(value);

                std::getline(ss, value, ',');
                entry.alpha_i = std::stod(value);

                std::getline(ss, value, ',');
                entry.EF_i5 = std::stod(value);

                std::getline(ss, value, ',');
                entry.GWP_i = std::stod(value);

                data.push_back(entry);
            }
            catch (const std::invalid_argument& e) {
                std::cerr << "Invalid data encountered in the file: " << e.what() << std::endl;
            }
            catch (const std::out_of_range& e) {
                std::cerr << "Out of range error encountered in the file: " << e.what() << std::endl;
            }
        }
        file.close();
    }
    else {
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
    return data;
}

std::vector<EnergyConsumptionData> readEnergyCSV(const std::string& filename) {
    std::vector<EnergyConsumptionData> data;
    std::ifstream file(filename);
    std::string line;
    if (file.is_open()) {
        bool firstLine = true;
        while (std::getline(file, line)) {
            if (firstLine) {
                firstLine = false;
                continue;
            }

            std::stringstream ss(line);
            std::string value;
            EnergyConsumptionData entry;

            // Skip the first column
            std::getline(ss, value, ',');

            try {
                std::getline(ss, value, ',');
                entry.Ei3 = std::stod(value);

                std::getline(ss, value, ',');
                entry.EF_i3 = std::stod(value);

                data.push_back(entry);
            }
            catch (const std::invalid_argument& e) {
                std::cerr << "Invalid data encountered in the file: " << e.what() << std::endl;
            }
            catch (const std::out_of_range& e) {
                std::cerr << "Out of range error encountered in the file: " << e.what() << std::endl;
            }
        }
        file.close();
    }
    else {
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
    return data;
}

int main() {
    std::string blackLiquorFilename = "C:/Users/youha/Desktop/uob��ҵ����/����ֽ�����ݺ�ˮ����.csv";
    std::string energyFilename = "C:/Users/youha/Desktop/uob��ҵ����/��ˮ������Դ����.csv";

    std::vector<BlackLiquorData> blackLiquorData = readBlackLiquorCSV(blackLiquorFilename);
    std::vector<EnergyConsumptionData> energyData = readEnergyCSV(energyFilename);

    double totalCarbonEmissions = 0.0;

    if (!blackLiquorData.empty()) {
        totalCarbonEmissions += calculateCarbonEmissions(blackLiquorData);
    }
    else {
        std::cerr << "No data available to calculate black liquor emissions." << std::endl;
    }

    if (!energyData.empty()) {
        totalCarbonEmissions += calculateEnergyCarbonEmissions(energyData);
    }
    else {
        std::cerr << "No data available to calculate energy consumption emissions." << std::endl;
    }

    std::cout << "Total Carbon Emissions (Black Liquor + Energy Consumption): " << totalCarbonEmissions << " tonnes" << std::endl;

    return 0;
}
